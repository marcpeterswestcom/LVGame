extends Area2D

## Obstacle (drink/party person) that the player must dodge
## Supports multiple movement patterns that increase in difficulty

@export var obstacle_type: String = "cocktail"
@export var move_pattern: int = 0  # GameManager.MovePattern enum value
@export var base_speed: float = 100.0

var world_pos := Vector2.ZERO
var config: Dictionary = {}
var phase: float = 0.0
var age: float = 0.0
var player_ref: Node2D = null

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D


func _ready():
	# Load config from game manager
	if GameManager and GameManager.OBSTACLE_TYPES.has(obstacle_type):
		config = GameManager.OBSTACLE_TYPES[obstacle_type]
	
	phase = randf() * TAU
	
	# Connect area signal for collision with player
	body_entered.connect(_on_body_entered)
	
	# Set sprite frame based on type
	if sprite and config.has("sprite_frame"):
		sprite.frame = config.sprite_frame


func initialize(type: String, pattern: int, pos: Vector2, player: Node2D):
	obstacle_type = type
	move_pattern = pattern
	world_pos = pos
	player_ref = player
	
	if GameManager and GameManager.OBSTACLE_TYPES.has(type):
		config = GameManager.OBSTACLE_TYPES[type]


func _process(delta: float):
	if not GameManager or GameManager.state != GameManager.GameState.PLAYING:
		return
	
	age += delta
	var speed = base_speed * config.get("speed_mult", 1.0)
	
	# Apply movement pattern
	match move_pattern:
		GameManager.MovePattern.STRAIGHT:
			world_pos.x -= speed * delta
		
		GameManager.MovePattern.ZIGZAG:
			world_pos.x -= speed * delta * 0.8
			world_pos.y += sin(age * 3.0 + phase) * speed * delta
		
		GameManager.MovePattern.DIAGONAL:
			world_pos.x -= speed * delta * 0.6
			world_pos.y += cos(phase) * speed * delta * 0.8
		
		GameManager.MovePattern.HOMING:
			if player_ref:
				var player_world = player_ref.get_world_pos() if player_ref.has_method("get_world_pos") else Vector2.ZERO
				var dir = (player_world - world_pos).normalized()
				world_pos += dir * speed * delta * 0.8
	
	# Convert to screen position
	position = _world_to_iso(world_pos)
	
	# Remove if too far behind the player
	if player_ref:
		var player_world = player_ref.get_world_pos() if player_ref.has_method("get_world_pos") else Vector2.ZERO
		if world_pos.x < player_world.x - 500:
			# Player dodged this obstacle — award points
			GameManager.add_score(GameManager.DODGE_SCORE)
			queue_free()


func _on_body_entered(body: Node2D):
	if body.is_in_group("player"):
		# Hit the player!
		GameManager.add_drunk(config.get("drunk_amount", 10.0))
		GameManager.add_score(config.get("score_penalty", -5))
		
		# Spawn hit particles (signal to particle manager or handle here)
		_spawn_hit_effect()
		
		queue_free()


func _spawn_hit_effect():
	# You can instantiate a particle scene here or emit a signal
	# For now, a simple visual feedback
	pass


static func _world_to_iso(world: Vector2) -> Vector2:
	return Vector2(
		(world.x - world.y),
		(world.x + world.y) * 0.5
	)
