extends Node2D

## Spawner - Creates obstacles and powerups ahead of the player

@export var obstacle_scene: PackedScene
@export var powerup_scene: PackedScene
@export var player: CharacterBody2D

var obstacle_timer: float = 0.0
var powerup_timer: float = 0.0
const POWERUP_INTERVAL: float = 2.5
const SPAWN_AHEAD_DISTANCE: float = 400.0  # world units ahead of player
const LANE_WIDTH: float = 80.0  # half-width of playable area


func _process(delta: float):
	if not GameManager or GameManager.state != GameManager.GameState.PLAYING:
		return
	if not player:
		return
	
	var spawn_rate = GameManager.get_spawn_rate()
	
	# Spawn obstacles
	obstacle_timer += delta
	if obstacle_timer >= spawn_rate:
		obstacle_timer = 0.0
		_spawn_obstacle()
	
	# Spawn powerups
	powerup_timer += delta
	if powerup_timer >= POWERUP_INTERVAL:
		powerup_timer = 0.0
		_spawn_powerup()


func _spawn_obstacle():
	if not obstacle_scene:
		return
	
	var obs = obstacle_scene.instantiate()
	var player_world = player.get_world_pos() if player.has_method("get_world_pos") else Vector2.ZERO
	
	var type = GameManager.get_random_obstacle_type()
	var pattern = GameManager.get_random_move_pattern()
	
	# Spawn ahead and to a random lane
	var spawn_pos = Vector2(
		player_world.x + SPAWN_AHEAD_DISTANCE + randf_range(0, 200),
		player_world.y + randf_range(-LANE_WIDTH, LANE_WIDTH)
	)
	
	obs.initialize(type, pattern, spawn_pos, player)
	add_child(obs)


func _spawn_powerup():
	if not powerup_scene:
		return
	
	var pu = powerup_scene.instantiate()
	var player_world = player.get_world_pos() if player.has_method("get_world_pos") else Vector2.ZERO
	
	var type = GameManager.get_random_powerup_type()
	
	# Spawn in a reachable lane ahead
	var spawn_pos = Vector2(
		player_world.x + SPAWN_AHEAD_DISTANCE + randf_range(50, 150),
		randf_range(-LANE_WIDTH * 0.7, LANE_WIDTH * 0.7)
	)
	
	pu.initialize(type, spawn_pos)
	add_child(pu)
