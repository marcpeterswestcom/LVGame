extends CanvasLayer

## UI Manager - Updates HUD elements based on game state

@onready var drunk_bar: ProgressBar = $DrunkBar
@onready var progress_bar: ProgressBar = $ProgressBar
@onready var score_label: Label = $ScoreLabel
@onready var landmark_label: Label = $LandmarkLabel
@onready var start_screen: Control = $StartScreen
@onready var end_screen: Control = $EndScreen
@onready var end_title: Label = $EndScreen/Title
@onready var end_score: Label = $EndScreen/Score

var landmark_display_timer: float = 0.0


func _ready():
	if GameManager:
		GameManager.drunk_level_changed.connect(_on_drunk_changed)
		GameManager.score_changed.connect(_on_score_changed)
		GameManager.distance_changed.connect(_on_distance_changed)
		GameManager.landmark_reached.connect(_on_landmark_reached)
		GameManager.game_over.connect(_on_game_over)
		GameManager.game_started.connect(_on_game_started)
	
	_show_start_screen()


func _process(delta: float):
	# Fade out landmark name
	if landmark_display_timer > 0:
		landmark_display_timer -= delta
		if landmark_label:
			landmark_label.modulate.a = clamp(landmark_display_timer / 0.5, 0.0, 1.0)


func _on_drunk_changed(level: float):
	if drunk_bar:
		drunk_bar.value = level
		# Color the bar based on level
		var style = drunk_bar.get_theme_stylebox("fill") as StyleBoxFlat
		if style:
			if level < 30:
				style.bg_color = Color.GREEN
			elif level < 60:
				style.bg_color = Color.YELLOW
			else:
				style.bg_color = Color.RED


func _on_score_changed(score: int):
	if score_label:
		score_label.text = "SCORE: %d" % score


func _on_distance_changed(distance: float, total: float):
	if progress_bar:
		progress_bar.value = (distance / total) * 100.0


func _on_landmark_reached(landmark_name: String, color: Color):
	if landmark_label:
		landmark_label.text = "✦ %s ✦" % landmark_name
		landmark_label.modulate = color
		landmark_label.modulate.a = 1.0
		landmark_display_timer = 2.5


func _on_game_over(won: bool):
	if end_screen:
		end_screen.visible = true
	
	if won:
		if end_title:
			end_title.text = "YOU MADE IT!"
			end_title.modulate = Color(0, 1, 0.8)
		if end_score:
			end_score.text = "FINAL SCORE: %d  ·  DRUNK: %d%%" % [
				GameManager.score,
				int(GameManager.drunk_level)
			]
	else:
		if end_title:
			end_title.text = "BLACKED OUT!"
			end_title.modulate = Color(1, 0.2, 0.2)
		if end_score:
			var landmark_name = "the start"
			if GameManager.current_landmark_index >= 0:
				landmark_name = GameManager.LANDMARKS[GameManager.current_landmark_index].name
			end_score.text = "Made it to %s  ·  SCORE: %d" % [landmark_name, GameManager.score]


func _on_game_started():
	if start_screen:
		start_screen.visible = false
	if end_screen:
		end_screen.visible = false


func _show_start_screen():
	if start_screen:
		start_screen.visible = true
	if end_screen:
		end_screen.visible = false


func _on_start_button_pressed():
	GameManager.start_game()


func _on_retry_button_pressed():
	GameManager.start_game()
