extends CharacterBody2D

## Player controller for Vegas Strip Survivor
## Handles isometric movement, drunk wobble, and collision response

@export var move_speed: float = 200.0
@export var lane_min_y: float = -100.0  # top lane boundary (iso world)
@export var lane_max_y: float = 100.0   # bottom lane boundary (iso world)

# Isometric conversion
# In isometric, we move in world space and convert to screen space
# World X = along the strip, World Y = across the strip
const ISO_ANGLE := PI / 6.0

var world_pos := Vector2.ZERO
var wobble_time: float = 0.0
var bobble_time: float = 0.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var drunk_particles: GPUParticles2D = $DrunkParticles  # optional


func _ready():
	# Connect to game manager signals
	if GameManager:
		GameManager.game_started.connect(_on_game_started)


func _on_game_started():
	world_pos = Vector2.ZERO
	position = world_to_iso(world_pos)


func _physics_process(delta: float):
	if not GameManager or GameManager.state != GameManager.GameState.PLAYING:
		return
	
	var input_dir := _get_input_direction()
	var drunk_ratio := GameManager.get_drunk_ratio()
	
	# Apply drunk wobble to movement
	wobble_time += delta * (2.0 + drunk_ratio * 4.0)
	var wobble := Vector2(
		sin(wobble_time) * drunk_ratio * 40.0,
		cos(wobble_time * 1.3) * drunk_ratio * 30.0
	)
	
	# Auto-forward movement along the strip
	var auto_forward := GameManager.scroll_speed
	
	# Calculate world-space movement
	var world_velocity := Vector2.ZERO
	world_velocity.x = auto_forward + input_dir.x * move_speed
	world_velocity.y = input_dir.y * move_speed
	
	# Add wobble
	world_velocity += wobble
	
	# Update world position
	world_pos += world_velocity * delta
	
	# Clamp Y to lane boundaries
	world_pos.y = clamp(world_pos.y, lane_min_y, lane_max_y)
	
	# Convert to isometric screen position
	position = world_to_iso(world_pos)
	
	# Update distance in game manager
	GameManager.add_distance(auto_forward * delta)
	
	# Bobble animation
	bobble_time += delta * 8.0
	if sprite:
		sprite.offset.y = sin(bobble_time) * 3.0
	
	# Drunk visual effects on player
	_update_drunk_visuals(drunk_ratio)


func _get_input_direction() -> Vector2:
	var dir := Vector2.ZERO
	
	if Input.is_action_pressed("move_up"):
		dir.y -= 1.0
	if Input.is_action_pressed("move_down"):
		dir.y += 1.0
	if Input.is_action_pressed("move_left"):
		dir.x -= 1.0
	if Input.is_action_pressed("move_right"):
		dir.x += 1.0
	
	# Normalize diagonal movement
	if dir.length() > 0:
		dir = dir.normalized()
	
	return dir


func _update_drunk_visuals(drunk_ratio: float):
	# Rotate slightly when drunk
	if drunk_ratio > 0.3:
		rotation = sin(wobble_time * 3.0) * drunk_ratio * 0.15
	else:
		rotation = 0.0
	
	# Scale pulse when very drunk
	if drunk_ratio > 0.6:
		var pulse = 1.0 + sin(wobble_time * 2.0) * 0.05
		scale = Vector2(pulse, pulse)
	else:
		scale = Vector2.ONE
	
	# Enable drunk particles
	if drunk_particles:
		drunk_particles.emitting = drunk_ratio > 0.4
		if drunk_ratio > 0.4:
			drunk_particles.amount = int(drunk_ratio * 10)


func get_world_pos() -> Vector2:
	return world_pos


## Convert world coordinates to isometric screen coordinates
static func world_to_iso(world: Vector2) -> Vector2:
	return Vector2(
		(world.x - world.y),
		(world.x + world.y) * 0.5
	)


## Convert isometric screen coordinates back to world coordinates
static func iso_to_world(iso: Vector2) -> Vector2:
	return Vector2(
		(iso.x + iso.y * 2.0) * 0.5,
		(iso.y * 2.0 - iso.x) * 0.5
	)
