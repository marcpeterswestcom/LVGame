extends Node

## Game Manager - Autoload singleton for Vegas Strip Survivor
## Handles game state, difficulty scaling, scoring, and drunk system

signal drunk_level_changed(level: float)
signal score_changed(score: int)
signal distance_changed(distance: float, total: float)
signal landmark_reached(name: String, color: Color)
signal game_over(won: bool)
signal game_started()

# --- Game State ---
enum GameState { MENU, PLAYING, PAUSED, WON, LOST }
var state: GameState = GameState.MENU

# --- Drunk System ---
var drunk_level: float = 0.0
const MAX_DRUNK: float = 100.0
const DRUNK_DECAY_RATE: float = 1.5  # per second, natural metabolism
const DRUNK_THRESHOLDS = {
	"sober": 0.0,
	"tipsy": 20.0,
	"buzzed": 40.0,
	"hammered": 60.0,
	"blackout_zone": 80.0,
}

# --- Scoring ---
var score: int = 0
const DODGE_SCORE: int = 10
const SOBRIETY_BONUS: int = 500  # if finish under 30% drunk

# --- Distance & Progress ---
var distance: float = 0.0
const TOTAL_DISTANCE: float = 3000.0
var current_landmark_index: int = -1

# --- Difficulty ---
var base_scroll_speed: float = 80.0  # pixels per second
var scroll_speed: float = 80.0
const MAX_SCROLL_SPEED: float = 200.0

# --- Landmarks ---
const LANDMARKS = [
	{ "dist": 0.0, "name": "Mandalay Bay", "color": Color.GOLD },
	{ "dist": 0.1, "name": "Luxor", "color": Color.ORANGE },
	{ "dist": 0.2, "name": "Excalibur", "color": Color(0.8, 0.2, 1.0) },
	{ "dist": 0.3, "name": "MGM Grand", "color": Color.GREEN },
	{ "dist": 0.4, "name": "Bellagio", "color": Color.DODGER_BLUE },
	{ "dist": 0.5, "name": "Caesars Palace", "color": Color.GOLD },
	{ "dist": 0.6, "name": "The Venetian", "color": Color(1.0, 0.6, 0.4) },
	{ "dist": 0.7, "name": "Treasure Island", "color": Color(1.0, 0.2, 0.4) },
	{ "dist": 0.8, "name": "Wynn", "color": Color.DARK_RED },
	{ "dist": 0.9, "name": "Circus Circus", "color": Color(1.0, 0.4, 0.8) },
	{ "dist": 1.0, "name": "Stratosphere", "color": Color(0.0, 1.0, 0.8) },
]

# --- Obstacle Configuration ---
const OBSTACLE_TYPES = {
	"cocktail": {
		"drunk_amount": 12.0,
		"speed_mult": 1.2,
		"size": 0.4,
		"score_penalty": -5,
		"sprite_frame": 0,  # map to your spritesheet
	},
	"beer": {
		"drunk_amount": 8.0,
		"speed_mult": 0.9,
		"size": 0.45,
		"score_penalty": -3,
		"sprite_frame": 1,
	},
	"shots": {
		"drunk_amount": 20.0,
		"speed_mult": 1.8,
		"size": 0.35,
		"score_penalty": -10,
		"sprite_frame": 2,
	},
	"champagne": {
		"drunk_amount": 15.0,
		"speed_mult": 1.0,
		"size": 0.5,
		"score_penalty": -8,
		"sprite_frame": 3,
	},
	"party_guy": {
		"drunk_amount": 10.0,
		"speed_mult": 0.7,
		"size": 0.6,
		"score_penalty": -5,
		"sprite_frame": 4,
	},
}

# --- Powerup Configuration ---
const POWERUP_TYPES = {
	"water": { "drunk_amount": -15.0, "score_bonus": 20, "sprite_frame": 0 },
	"coffee": { "drunk_amount": -10.0, "score_bonus": 15, "sprite_frame": 1 },
	"taco": { "drunk_amount": -8.0, "score_bonus": 25, "sprite_frame": 2 },
	"pizza": { "drunk_amount": -12.0, "score_bonus": 20, "sprite_frame": 3 },
}

# --- Movement Patterns ---
enum MovePattern { STRAIGHT, ZIGZAG, DIAGONAL, HOMING }


func _ready():
	pass


func _process(delta: float):
	if state != GameState.PLAYING:
		return
	
	# Natural drunk decay (metabolism)
	drunk_level = max(0.0, drunk_level - DRUNK_DECAY_RATE * delta)
	drunk_level_changed.emit(drunk_level)
	
	# Update difficulty based on progress
	var progress = distance / TOTAL_DISTANCE
	scroll_speed = base_scroll_speed + progress * (MAX_SCROLL_SPEED - base_scroll_speed)
	
	# Check landmarks
	_check_landmarks(progress)
	
	# Check win/lose
	if drunk_level >= MAX_DRUNK:
		_end_game(false)
	elif distance >= TOTAL_DISTANCE:
		_end_game(true)


func start_game():
	drunk_level = 0.0
	score = 0
	distance = 0.0
	current_landmark_index = -1
	scroll_speed = base_scroll_speed
	state = GameState.PLAYING
	game_started.emit()


func add_drunk(amount: float):
	drunk_level = clamp(drunk_level + amount, 0.0, MAX_DRUNK)
	drunk_level_changed.emit(drunk_level)


func add_score(amount: int):
	score += amount
	score = max(0, score)
	score_changed.emit(score)


func add_distance(amount: float):
	distance += amount
	distance_changed.emit(distance, TOTAL_DISTANCE)


func get_progress() -> float:
	return distance / TOTAL_DISTANCE


func get_drunk_ratio() -> float:
	return drunk_level / MAX_DRUNK


func get_drunk_state() -> String:
	if drunk_level >= DRUNK_THRESHOLDS.blackout_zone:
		return "blackout_zone"
	elif drunk_level >= DRUNK_THRESHOLDS.hammered:
		return "hammered"
	elif drunk_level >= DRUNK_THRESHOLDS.buzzed:
		return "buzzed"
	elif drunk_level >= DRUNK_THRESHOLDS.tipsy:
		return "tipsy"
	return "sober"


func get_difficulty() -> float:
	## Returns 1.0 to 3.0 based on progress
	return 1.0 + get_progress() * 2.0


func get_spawn_rate() -> float:
	## Seconds between obstacle spawns — decreases with difficulty
	return max(0.4, 1.2 - get_difficulty() * 0.15)


func get_random_obstacle_type() -> String:
	var types = OBSTACLE_TYPES.keys()
	return types[randi() % types.size()]


func get_random_powerup_type() -> String:
	var types = POWERUP_TYPES.keys()
	return types[randi() % types.size()]


func get_random_move_pattern() -> MovePattern:
	var difficulty = get_difficulty()
	# Homing enemies become more common with difficulty
	var weights = [3, 2, 2, int(difficulty)]
	var total = 0
	for w in weights:
		total += w
	var roll = randi() % total
	var cumulative = 0
	for i in range(weights.size()):
		cumulative += weights[i]
		if roll < cumulative:
			return i as MovePattern
	return MovePattern.STRAIGHT


func _check_landmarks(progress: float):
	for i in range(LANDMARKS.size()):
		if progress >= LANDMARKS[i].dist and i > current_landmark_index:
			current_landmark_index = i
			landmark_reached.emit(LANDMARKS[i].name, LANDMARKS[i].color)


func _end_game(won: bool):
	if won:
		state = GameState.WON
		# Sobriety bonus
		if drunk_level < 30.0:
			add_score(SOBRIETY_BONUS)
	else:
		state = GameState.LOST
	game_over.emit(won)
