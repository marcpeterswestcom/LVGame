extends Area2D

## Powerup (water, coffee, food) that reduces drunk level

@export var powerup_type: String = "water"

var world_pos := Vector2.ZERO
var config: Dictionary = {}
var bobble_time: float = 0.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var glow: PointLight2D = $Glow  # optional glow effect


func _ready():
	if GameManager and GameManager.POWERUP_TYPES.has(powerup_type):
		config = GameManager.POWERUP_TYPES[powerup_type]
	
	bobble_time = randf() * TAU
	body_entered.connect(_on_body_entered)
	
	if sprite and config.has("sprite_frame"):
		sprite.frame = config.sprite_frame


func initialize(type: String, pos: Vector2):
	powerup_type = type
	world_pos = pos
	
	if GameManager and GameManager.POWERUP_TYPES.has(type):
		config = GameManager.POWERUP_TYPES[type]


func _process(delta: float):
	if not GameManager or GameManager.state != GameManager.GameState.PLAYING:
		return
	
	bobble_time += delta * 4.0
	
	# Convert world to iso with bobble
	var iso = _world_to_iso(world_pos)
	iso.y += sin(bobble_time) * 5.0
	position = iso
	
	# Pulse glow
	if glow:
		glow.energy = 0.8 + sin(bobble_time * 2.0) * 0.3


func _on_body_entered(body: Node2D):
	if body.is_in_group("player"):
		GameManager.add_drunk(config.get("drunk_amount", -10.0))
		GameManager.add_score(config.get("score_bonus", 15))
		_spawn_collect_effect()
		queue_free()


func _spawn_collect_effect():
	# Instantiate a sparkle/heal particle effect here
	pass


static func _world_to_iso(world: Vector2) -> Vector2:
	return Vector2(
		(world.x - world.y),
		(world.x + world.y) * 0.5
	)
