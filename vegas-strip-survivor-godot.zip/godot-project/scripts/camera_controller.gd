extends Camera2D

## Camera that follows the player with drunk-level-dependent screen shake

@export var target: Node2D
@export var follow_speed: float = 3.0
@export var lead_amount: float = 100.0  # look-ahead distance

var shake_time: float = 0.0


func _ready():
	if GameManager:
		GameManager.game_started.connect(_on_game_started)


func _on_game_started():
	if target:
		global_position = target.global_position


func _process(delta: float):
	if not target:
		return
	if not GameManager or GameManager.state != GameManager.GameState.PLAYING:
		return
	
	# Smooth follow with lead
	var target_pos = target.global_position + Vector2(lead_amount, 0)
	global_position = global_position.lerp(target_pos, follow_speed * delta)
	
	# Drunk shake
	var drunk_ratio = GameManager.get_drunk_ratio()
	if drunk_ratio > 0.3:
		shake_time += delta
		var intensity = (drunk_ratio - 0.3) * 15.0
		offset = Vector2(
			sin(shake_time * 8.0) * intensity,
			cos(shake_time * 6.5) * intensity * 0.6
		)
	else:
		offset = offset.lerp(Vector2.ZERO, 5.0 * delta)
