extends CanvasLayer

## Drunk screen effects overlay
## Applies vignette, color tint, and visual distortion based on drunk level

@onready var vignette: ColorRect = $Vignette
@onready var flash_rect: ColorRect = $FlashRect

var flash_alpha: float = 0.0
var flash_color: Color = Color.RED
var time: float = 0.0


func _ready():
	# Set up vignette shader (you'll need a vignette shader material)
	# For now we use a simple ColorRect with transparency
	if vignette:
		vignette.color = Color(0, 0, 0, 0)
		vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	
	if flash_rect:
		flash_rect.color = Color(1, 0, 0, 0)
		flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float):
	if not GameManager:
		return
	
	time += delta
	var drunk_ratio = GameManager.get_drunk_ratio()
	
	# Vignette darkness increases with drunkenness
	if vignette:
		var vignette_alpha = 0.0
		if drunk_ratio > 0.2:
			vignette_alpha = (drunk_ratio - 0.2) * 0.7
		vignette.color = Color(0, 0, 0, vignette_alpha)
	
	# Flash decay
	if flash_alpha > 0:
		flash_alpha = max(0, flash_alpha - delta * 3.0)
		if flash_rect:
			flash_rect.color = Color(flash_color.r, flash_color.g, flash_color.b, flash_alpha)
	
	# Purple/blurry tint when very drunk
	if drunk_ratio > 0.6 and vignette:
		var tint_strength = (drunk_ratio - 0.6) * 0.3
		vignette.color = Color(0.2 * tint_strength, 0, 0.3 * tint_strength, vignette.color.a)


func trigger_flash(color: Color, intensity: float = 0.4):
	flash_color = color
	flash_alpha = intensity


func trigger_hit_flash():
	trigger_flash(Color(1, 0, 0.2), 0.4)


func trigger_heal_flash():
	trigger_flash(Color(0, 1, 0.5), 0.3)
