# 🎰 Vegas Strip Survivor — Godot Project

## Quick Start

1. **Open in Godot 4.2+** — Open the `project.godot` file
2. **Register the Autoload** — Go to `Project > Project Settings > Autoload` and add `scripts/game_manager.gd` as `GameManager`
3. **Create scenes** from the scripts (see Scene Setup below)
4. **Add art assets** — Replace placeholder sprites with your own art

## Project Structure

```
godot-project/
├── project.godot              # Godot project config
├── scripts/
│   ├── game_manager.gd        # Autoload singleton — game state, scoring, drunk system
│   ├── player.gd              # Player movement with isometric conversion + drunk wobble
│   ├── obstacle.gd            # Drink/party obstacles with 4 movement patterns
│   ├── powerup.gd             # Water/coffee/food collectibles
│   ├── spawner.gd             # Spawns obstacles & powerups ahead of player
│   ├── camera_controller.gd   # Camera follow with drunk screen shake
│   ├── drunk_effects.gd       # Screen overlay effects (vignette, flash, tint)
│   └── ui_manager.gd          # HUD updates (drunk bar, progress, score, landmarks)
├── scenes/                    # Create these from the scripts
└── resources/                 # Art, audio, shaders
```

## Scene Setup Guide

### 1. Player Scene (`player.tscn`)
- **Root**: `CharacterBody2D` (attach `player.gd`)
  - Add to group: `"player"`
  - **Sprite2D** — your player sprite
  - **CollisionShape2D** — `CircleShape2D` radius ~16
  - **DrunkParticles** (`GPUParticles2D`) — optional swirl particles

### 2. Obstacle Scene (`obstacle.tscn`)
- **Root**: `Area2D` (attach `obstacle.gd`)
  - **Sprite2D** — drink/party emoji sprite
  - **CollisionShape2D** — `CircleShape2D` radius ~12
  - Set collision layer/mask to detect player body

### 3. Powerup Scene (`powerup.tscn`)
- **Root**: `Area2D` (attach `powerup.gd`)
  - **Sprite2D** — water/coffee/food sprite
  - **CollisionShape2D** — `CircleShape2D` radius ~14
  - **Glow** (`PointLight2D`) — optional green glow

### 4. Main Scene (`main.tscn`)
- **Root**: `Node2D`
  - **Player** (instance `player.tscn`)
  - **Spawner** (`Node2D`, attach `spawner.gd`)
    - Set `obstacle_scene` and `powerup_scene` exports to your packed scenes
    - Set `player` reference
  - **Camera2D** (attach `camera_controller.gd`)
    - Set `target` to Player node
  - **DrunkEffects** (`CanvasLayer`, attach `drunk_effects.gd`)
    - **Vignette** (`ColorRect`, full screen)
    - **FlashRect** (`ColorRect`, full screen)
  - **UI** (`CanvasLayer`, attach `ui_manager.gd`)
    - **DrunkBar** (`ProgressBar`, max=100)
    - **ProgressBar** (`ProgressBar`, max=100)
    - **ScoreLabel** (`Label`)
    - **LandmarkLabel** (`Label`, centered)
    - **StartScreen** (`Control` with title + start button)
    - **EndScreen** (`Control` with title + score + retry button)

## Input Map
Already configured in `project.godot`:
- `move_up` — W / ↑
- `move_down` — S / ↓
- `move_left` — A / ←
- `move_right` — D / →

## Key Design Decisions

### Isometric Conversion
All game logic runs in **world space** (X = along strip, Y = across strip). The `world_to_iso()` function converts to screen coordinates:
```gdscript
static func world_to_iso(world: Vector2) -> Vector2:
    return Vector2(
        (world.x - world.y),
        (world.x + world.y) * 0.5
    )
```

### Difficulty Scaling
- `get_difficulty()` returns 1.0–3.0 based on strip progress
- Obstacle spawn rate decreases (more frequent) with difficulty
- Homing obstacles become more common later
- Auto-scroll speed increases from 80 to 200 px/sec

### Drunk System
- Natural decay: -1.5/sec (your body metabolizes)
- Hits from drinks: +8 to +20 depending on type
- Powerups: -8 to -15
- Visual effects kick in at 30%+ drunk
- Game over at 100%

## Next Steps
- [ ] Create sprite sheets for drinks, powerups, and player
- [ ] Build isometric tilemap for the road/sidewalk
- [ ] Add procedural building generator for strip scenery
- [ ] Add sound effects and music
- [ ] Add particle effects for collisions
- [ ] Polish UI with Vegas-themed fonts and neon styling
- [ ] Add casino-specific hazard zones per landmark
